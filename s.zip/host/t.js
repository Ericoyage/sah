const { Client, GatewayIntentBits, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
const { Client: SSHClient } = require('ssh2');
const fs = require('fs');
const readline = require('readline');
const CONFIG_FILE_PATH = '/home/master/sah/Eriiiic/log.json';  // Path to the JSON file you want to update

const DISCORD_TOKEN = '';
const SSH_CONFIG = {
    host: '159.203.160.67',
    port: 22,
    username: 'master_mhvdscdpzs',
    password: 'Ssaa1122'
};

const ERROR_CHANNEL_ID = '1284504473737232498';  // Error reporting channel ID
let runDelay = 140000;  // Default time delay between bot launches in milliseconds
const activeTokens = new Set();  // Tokens that have been used
let usedTokens = new Set();  // To store used tokens

const bot = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
    ]
});

bot.once('ready', () => {
    console.log(`تم تسجيل الدخول كـ ${bot.user.tag}`);
});

// Error handling - send errors to a specific channel
bot.on('error', (error) => {
    const errorChannel = bot.channels.cache.get(ERROR_CHANNEL_ID);
    if (errorChannel) {
        errorChannel.send(`حدث خطأ: ${error.message}`);
    } else {
        console.error('لم يتم العثور على قناة الخطأ.');
    }
});

// Command to display the help menu using select menus
bot.on('messageCreate', async message => {
    if (message.content === '!help') {
        // Create a select menu for commands
        const row = new ActionRowBuilder()
            .addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('help_select')
                    .setPlaceholder('اختر أمراً')
                    .addOptions([
                        
                        {
                            label: 'تشغيل جميع التوكنات',
                            description: 'تشغيل جميع التوكنات في الملف بتأخير 10 ثواني',
                            value: 'run_all_tokens'
                        },
                        {
                            label: 'تشغيل التوكنات',
                            description: 'قم بتشغيل عدد معين من التوكنات',
                            value: 'run_tokens',
                        },
                        {
                            label: 'تشغيل التوكنات بشكل فردي',
                            description: 'تشغيل التوكنات واحداً تلو الآخر',
                            value: 'run_one_by_one',
                        },
                        {
                            label: 'تغيير وقت التأخير',
                            description: 'تغيير الوقت المدد بين تشغيل التوكنات',
                            value: 'set_delay',
                        },
                        {
                            label: 'عرض التوكنات المتبقية',
                            description: 'عرض التوكنات المتاحة لتشغيلها',
                            value: 'tokens_left',
                        },
                        {
                            label: 'عرض التوكنات المستخدمة',
                            description: 'عرض التوكنات التي تم تشغيلها',
                            value: 'tokens_used',
                        }
                    ])
            );

        // Send the select menu
        await message.reply({ content: '⚙️ **اختر أحد أوامر البوت من القائمة أدناه:**', components: [row] });
    }
});

// Handle select menu interactions
bot.on('interactionCreate', async interaction => {
    if (!interaction.isStringSelectMenu()) return;

    const tokens = await readTokensFromFile('tokens.txt');
    const availableTokens = tokens.filter(token => !activeTokens.has(token));

    switch (interaction.values[0]) {
        case 'run_tokens':
            await interaction.reply('💻 استخدم الأمر `!run <number>` لتشغيل عدد معين من التوكنات.');
            break;

        case 'run_one_by_one':
            await interaction.reply('💻 استخدم الأمر `!runonebyone` لتشغيل التوكنات واحداً تلو الآخر.');
            break;

        case 'set_delay':
            await interaction.reply('⏳ استخدم الأمر `!setdelay <milliseconds>` لتغيير وقت التأخير بين تشغيل التوكنات.');
            break;

        case 'tokens_left':
            await interaction.reply(`🔍 هناك ${availableTokens.length} توكنات متاحة لتشغيلها.`);
            break;

        case 'tokens_used':
            await interaction.reply(`🔧 التوكنات التي تم استخدامها: ${usedTokens.size}.`);
            break;

        case 'run_all_tokens':
            await interaction.reply('🕑 جاري تشغيل جميع التوكنات بتأخير 10 ثواني بين كل واحد...');
            runAllTokens(interaction, tokens);
            break;

        default:
            await interaction.reply('⚠️ أمر غير صالح.');
            break;
    }
});

// Define the command to set the delay between running tokens
bot.on('messageCreate', async message => {
    if (message.content.startsWith('!setdelay')) {
        const args = message.content.split(' ');
        const newDelay = parseInt(args[1], 10);

        if (isNaN(newDelay) || newDelay <= 0) {
            message.reply('❌ الرجاء إدخال وقت تأخير صالح.');
            return;
        }

        runDelay = newDelay;
        message.reply(`⏳ تم تعيين وقت التأخير بين تشغيل التوكنات إلى ${runDelay} مللي ثانية.`);
    }
});

// Function to run all tokens with a 10s delay between each
async function runAllTokens(interaction, tokens) {
    const availableTokens = tokens.filter(token => !activeTokens.has(token));
    if (availableTokens.length === 0) {
        interaction.followUp('❌ لا توجد توكنات متاحة لتشغيلها.');
        return;
    }

    for (let i = 0; i < availableTokens.length; i++) {
        const token = availableTokens[i];

        // Mark token as active and used immediately to prevent duplicates
        activeTokens.add(token);
        usedTokens.add(token);

        try {
            await runBotOnSSH(interaction, token, i + 1);
            await new Promise(resolve => setTimeout(resolve, runDelay)); // Use the dynamic delay
        } catch (err) {
            interaction.followUp(`❌ حدث خطأ عند تشغيل التوكن: ${token}`);
        }
    }
}


// Other functions like reading tokens and SSH execution remain unchanged
async function readTokensFromFile(filePath) {
    const fileStream = fs.createReadStream(filePath);
    const rl = readline.createInterface({
        input: fileStream,
        crlfDelay: Infinity
    });

    const tokens = [];
    for await (const line of rl) {
        tokens.push(line.trim());
    }

    return tokens;
}

async function runBotOnSSH(interaction, token, index) {
    return new Promise((resolve, reject) => {
        const conn = new SSHClient();
        conn.on('ready', () => {
            console.log('SSH Client :: ready');
            conn.exec('cd /home/master/sah/Eriiiic && screen -dmS bot_session_name node index.js', (err, stream) => {
                if (err) {
                    interaction.reply(`❌ فشل في تنفيذ الأمر.`);
                    reject(err);
                    return;
                }

                activeTokens.add(token);
                usedTokens.add(token);  // Track the used tokens
                resolve();  // Resolve the promise after successful execution
            });
        }).connect(SSH_CONFIG);
    });
}

bot.on('messageCreate', async message => {
    if (message.content.startsWith('!set')) {
        const args = message.content.split(' ');

        if (args.length < 3) {
            message.reply('❌ الاستخدام الصحيح: `!updateconfig <key> <value>`');
            return;
        }

        const key = args[1];
        const value = args.slice(2).join(' ');

        if (!['categories', 'log', 'screen', 'errorlog'].includes(key)) {
            message.reply('❌ مفتاح غير صالح. المفاتيح المسموحة هي: `categories`, `log`, `screen`, `errorlog`.');
            return;
        }

        // Update the file on the server via SSH
        await updateConfigOnServer(key, value, (err) => {
            if (err) {
                message.reply(`❌ فشل في تحديث الملف: ${err.message}`);
            } else {
                message.reply(`✅ تم تحديث المفتاح **${key}** إلى **${value}** بنجاح.`);
            }
        });
    }
});

// Function to update the JSON file on the SSH server
function updateConfigOnServer(key, value, callback) {
    const conn = new SSHClient();
    conn.on('ready', () => {
        console.log('SSH Client :: ready');

        // Read the file from the server
        conn.exec(`cat ${CONFIG_FILE_PATH}`, (err, stream) => {
            if (err) {
                callback(err);
                return;
            }

            let fileData = '';
            stream.on('data', (data) => {
                fileData += data.toString();
            });

            stream.on('end', () => {
                try {
                    // Parse the JSON data
                    const jsonData = JSON.parse(fileData);
                    // Update the specific key with the new value
                    jsonData[key] = value;

                    // Convert JSON back to a string
                    const updatedData = JSON.stringify(jsonData, null, 4);

                    // Write the updated JSON back to the file on the server
                    conn.exec(`echo '${updatedData}' > ${CONFIG_FILE_PATH}`, (writeErr) => {
                        if (writeErr) {
                            callback(writeErr);
                        } else {
                            callback(null);
                        }
                        conn.end();
                    });
                } catch (parseErr) {
                    callback(parseErr);
                }
            });
        });
    }).connect(SSH_CONFIG);
}

bot.login(DISCORD_TOKEN);
