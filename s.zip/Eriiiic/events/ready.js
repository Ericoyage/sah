const utils = require('../utils');
const Discord = require("discord.js-selfbot-v13");

module.exports = client => {
    utils.log(`Logged in as ${client.user.username} !`);

};