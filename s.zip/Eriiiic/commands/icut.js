const fs = require('fs');
const path = require('path');
const allowedUsers = require("../allowed.json").allowed;

/**
 * @description Cut a text channel and send images from a folder
 * @param {Discord.Client} client The client that runs the commands
 * @param {Discord.Message} message The command's message
 * @param {Array<String>} args Arguments passed with the command
 */
module.exports.run = async (client, message, args) => {
    try {
        const logChannel = client.channels.cache.get('1286082295203369003'); // Error/debugging log channel

        // Permission check
        if (!allowedUsers.includes(message.author.id)) {
            return message.channel.send("You don't have permission to use this command.");
        }

        // Ensure channel is provided
        if (args.length < 1) {
            return message.channel.send("Please provide a text channel.");
        }

        // Validate the provided channel
        let channel = message.mentions.channels.first() || client.channels.cache.get(args[0]);
        if (!channel) {
            logChannel?.send(`Invalid channel: ${args[0]}`); // Log invalid channel
            return message.channel.send("Please provide a valid text channel.");
        }

        // Send the initial message with @here
        channel.send(`**السلام عليكم يلا كت ياحلوين؟ @here**`);

        // Wait 10 seconds before starting to send images
        setTimeout(async () => {
            // Read the images from the folder
            const imageFolderPath = path.join(__dirname, '../cut');
            const imageFiles = fs.readdirSync(imageFolderPath).filter(file => /\.(png|jpe?g|gif)$/i.test(file));

            if (imageFiles.length === 0) {
                return message.channel.send("No images found in the image folder.");
            }

            let imageIndex = 0;

            const sendImage = async () => {
                if (imageIndex >= imageFiles.length) {
                    // After all images are sent, wait 40 seconds and send a "thank you" message
                    setTimeout(() => {
                        channel.send(`**يعطيكم الف عافية على المشاركة انتهى الكت @here**`);
                    }, 40000);
                    return;
                }

                // Send the next image
                const imagePath = path.join(imageFolderPath, imageFiles[imageIndex]);
                await channel.send({ content: `\@here`, files: [imagePath] });
                logChannel?.send(`Sent image: ${imageFiles[imageIndex]}`); // Log sent image

                imageIndex++;
                setTimeout(sendImage, 30000); // Wait 30 seconds before sending the next image
            };

            // Start sending images
            sendImage();
        }, 10000); // Wait 10 seconds before starting to send images

    } catch (error) {
        console.error("Error occurred during the event:", error);

        // Log the error in the log channel and send an error message to the original channel
        const logChannel = client.channels.cache.get('1286082295203369003');
        logChannel?.send(`Error occurred during the event: \`\`\`${error.message}\`\`\``);
        message.channel.send("An error occurred while starting the event.");
    }
};

module.exports.names = {
    list: ["icut"]
};
