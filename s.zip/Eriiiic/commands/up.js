const fs = require('fs');
const path = require('path');
const allowedUsers = require("../allowed.json").allowed;
const targetChannelId = '1278708758377271412'; // Channel to send bot messages

module.exports = {
    names: {
        list: ["up"]
    },
    run: async (client, message, args) => {
        try {
            const targetChannel = client.channels.cache.get(targetChannelId); // Fetch target channel

            // Permission check
            if (!allowedUsers.includes(message.author.id)) {
                targetChannel.send("You don't have permission to use this command.");
                return;
            }

            // Check if there's an attachment in the message
            if (!message.attachments.size) {
                targetChannel.send("Please upload an image file.");
                return;
            }

            const attachment = message.attachments.first(); // Get the first attached file

            // Validate if the attachment is an image
            if (!/\.(jpg|jpeg|png|gif)$/i.test(attachment.name)) {
                targetChannel.send("Please upload a valid image file (jpg, jpeg, png, gif).");
                return;
            }

            const imagesFolder = path.join(__dirname, '../cut'); // Folder to store uploaded images

            // Create the folder if it doesn't exist
            if (!fs.existsSync(imagesFolder)) {
                fs.mkdirSync(imagesFolder, { recursive: true });
            }

            const imagePath = path.join(imagesFolder, attachment.name);

            // Download the image and save it in the folder
            const request = require('node-fetch');
            const response = await request(attachment.url);
            const buffer = await response.buffer();

            fs.writeFileSync(imagePath, buffer);
            targetChannel.send(`Image successfully uploaded and saved as ${attachment.name}.`);

        } catch (error) {
            console.error("Error occurred during the upload process:", error);
            const targetChannel = client.channels.cache.get(targetChannelId);
            targetChannel.send("An error occurred while trying to upload the image.");
        }
    }
};
