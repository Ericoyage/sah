const fs = require('fs');
const path = require('path');
const allowedUsers = require("../allowed.json").allowed;
const targetChannelId = '1278708758377271412'; // Channel to send bot messages
let interval = null; // Store the message interval
let stopLoop = false; // Control flag for stopping the loop

module.exports = {
    names: {
        list: ["athkar"]
    },
    run: async (client, message, args) => {
        try {
            const targetChannel = client.channels.cache.get(targetChannelId); // Fetch target channel

            // Permission check
            if (!allowedUsers.includes(message.author.id)) {
                targetChannel.send("You don't have permission to use this command.");
                return;
            }

            // Handle the stop command
            if (message.content.startsWith('atkarstop')) {
                if (interval) {
                    clearInterval(interval); // Stop the interval
                    interval = null; // Reset the interval
                    targetChannel.send(`Bank stopped, no more random images in this channel.`);
                    stopLoop = true; // Stop the loop flag
                } else {
                    targetChannel.send("The bank process is not running.");
                }
                return; // Exit the function
            }

            // Proceed with the normal bank process
            if (args.length < 1) {
                targetChannel.send("Please provide a text channel ID.");
                return;
            }

            const channelId = args[0];
            const channel = client.channels.cache.get(channelId);

            if (!channel || channel.type !== 'GUILD_TEXT') {
                targetChannel.send("Please provide a valid text channel ID.");
                return;
            }

            stopLoop = false; // Reset the stop flag

            // Function to send a random image
            const sendRandomImage = async () => {
                if (stopLoop) return; // Stop if flag is set
                
                const imagesFolder = path.join(__dirname, '../images'); // Adjust the folder path if necessary
                const files = fs.readdirSync(imagesFolder).filter(file => /\.(jpg|jpeg|png|gif)$/i.test(file));

                if (files.length === 0) {
                    targetChannel.send("No images found in the folder.");
                    return;
                }

                const randomImage = files[Math.floor(Math.random() * files.length)];
                const imagePath = path.join(imagesFolder, randomImage);

                await channel.send({ files: [imagePath] });
            };

            const startBankImages = async () => {
                if (stopLoop) return; // Stop if the loop flag is set

                // Send a random image immediately
                await sendRandomImage();

                // Send a random image every 6 hours (21600000 milliseconds)
                interval = setInterval(async () => {
                    await sendRandomImage();
                }, 21600000); // 6 hours in milliseconds
            };

            // Start the bank process (send images)
            startBankImages();

            targetChannel.send(`**Started sending random images in ${channel.toString()} every 6 hours.**`);

        } catch (error) {
            console.error("Error occurred during the event:", error);
            const targetChannel = client.channels.cache.get(targetChannelId);
            targetChannel.send("An error occurred while trying to start the image bank process.");
        }
    }
};
