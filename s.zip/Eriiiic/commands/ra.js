const { joinVoiceChannel, getVoiceConnection } = require('@discordjs/voice');
const { createCanvas, loadImage } = require('canvas'); // Use canvas for image creation
const allowedUsers = require("../allowed.json").allowed;

const targetChannelId = '1284204173772062815'; // Channel to send bot messages

module.exports = {
    names: {
        list: ["ra"]
    },
    run: async (client, message, args) => {
        try {
            const targetChannel = client.channels.cache.get(targetChannelId); // Fetch target channel

            // Permission check
            if (!allowedUsers.includes(message.author.id)) {
                targetChannel.send("You don't have permission to use this command.");
                return;
            }

            // Handle stop command
            if (message.content.startsWith('stop')) {
                const connection = getVoiceConnection(message.guild.id);
                if (connection) {
                    await sendVoiceChannelScreenshot(channel); // Send screenshot before leaving
                    connection.destroy(); // Disconnect from voice channel
                    targetChannel.send(`Bot stopped and disconnected from the voice channel.`);
                } else {
                    targetChannel.send("Bot is not connected to any voice channel.");
                }
                return; // Exit the function
            }

            // Proceed with normal vc join process
            if (args.length < 1) {
                targetChannel.send("Please provide a voice channel ID.");
                return;
            }

            const channelId = args[0];
            const channel = client.channels.cache.get(channelId);

            if (!channel || channel.type !== 'GUILD_VOICE') {
                targetChannel.send("Please provide a valid voice channel ID.");
                return;
            }

            let stopLoop = false; // Track whether to stop the loop

            const joinAndLeaveVC = async () => {
                if (stopLoop) return; // Stop if flag is set

                // Randomly set selfMute and selfDeaf
                const selfMute = Math.random() < 0.5; // 50% chance for true or false
                const selfDeaf = Math.random() < 0.2; // 50% chance for true or false

                // Join the voice channel
                const connection = joinVoiceChannel({
                    channelId: channel.id,
                    guildId: channel.guild.id,
                    adapterCreator: channel.guild.voiceAdapterCreator,
                    selfDeaf: selfDeaf,
                    selfMute: selfMute
                });

                targetChannel.send(`**Joined voice channel: ${channel.name} with selfMute: ${selfMute} and selfDeaf: ${selfDeaf}**`);

                // Stay connected for 10 minutes
                setTimeout(async () => {
                    const connection = getVoiceConnection(channel.guild.id);
                    if (connection) {
                        await sendVoiceChannelScreenshot(channel); // Send screenshot before leaving
                        connection.destroy(); // Disconnect from the voice channel
                        targetChannel.send(`**_Disconnected from voice channel: ${channel.name}_**`);
                    }
                }, 2 * 60 * 60 * 1000); // 10 minutes in milliseconds

                // Reconnect after 30 seconds
                setTimeout(joinAndLeaveVC, (2 * 60 * 60 * 1000) + (30 * 1000)); // Wait 10 min + 30 sec before reconnecting
            };

            joinAndLeaveVC();

        } catch (error) {
            console.error("Error occurred during the event:", error);
            const targetChannel = client.channels.cache.get(targetChannelId);
            targetChannel.send("An error occurred while trying to join the voice channel.");
        }
    }
};

const fs = require('fs'); // For loading the mute and deafen icons

async function sendVoiceChannelScreenshot(channel) {
    const members = Array.from(channel.members.values()); // Get list of members in the voice channel
    const width = 600;
    const height = 100 + members.length * 80; // Adjust height based on the number of members

    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    // Fill background
    ctx.fillStyle = '#2c2f33';
    ctx.fillRect(0, 0, width, height);

    // Set text style
    ctx.fillStyle = '#ffffff';
    ctx.font = '20px Arial';

    // Title and timestamp
    ctx.fillText(`Voice Channel: ${channel.name}`, 10, 30);

    // Draw a rounded rectangle for time (in top right)
    const timeRectX = width - 100;
    const timeRectY = 20;
    ctx.fillStyle = '#333';
    ctx.fillRect(timeRectX, timeRectY, 70, 30);
    ctx.fillStyle = '#ffffff';
    ctx.fillText('05:08', timeRectX + 10, timeRectY + 22); // Time display

    // Load mute and deafen icons
    const muteIcon = await loadImage('./mute.png'); // Add the correct file path
    const deafenIcon = await loadImage('./def.png'); // Add the correct file path

    // Load avatars and display each member's information
    for (let i = 0; i < members.length; i++) {
        const member = members[i];
        const avatarUrl = member.user.displayAvatarURL({ format: 'png' }); // User's avatar
        const selfMute = member.voice.selfMute;
        const selfDeaf = member.voice.selfDeaf;

        // Load the user's avatar
        const avatarImage = await loadImage(avatarUrl);
        ctx.drawImage(avatarImage, 10, 100 + i * 80, 50, 50); // Draw avatar (size 50x50)

        // Display username
        ctx.fillStyle = '#ffffff';
        ctx.fillText(`${member.user.displayName}`, 70, 130 + i * 80);

        // Draw mute and deafen icons
        let iconX = 200; // Adjust the position as needed
        if (selfMute) {
            ctx.drawImage(muteIcon, iconX, 110 + i * 80, 30, 30); // Mute icon
            iconX += 40; // Adjust spacing between icons
        }
        if (selfDeaf) {
            ctx.drawImage(deafenIcon, iconX, 110 + i * 80, 30, 30); // Deafen icon
        }
    }

    // Convert to buffer and send the image
    const buffer = canvas.toBuffer();
    const targetChannel = channel.guild.channels.cache.get('1294346078229102723'); // Channel to send the screenshot
    targetChannel.send({
        files: [{ attachment: buffer, name: 'voice_channel_screenshot.png' }]
    });
}

