const allowedUsers = require("../allowed.json").allowed;
let isListening = false;  // Track whether the bot is already listening

/**
 * @description Command to listen for another bot's message and click a button with the word "انضمام"
 * @param {Discord.Client} client The client that runs the commands
 * @param {Discord.Message} message The command's message
 * @param {Array<String>} args Arguments passed with the command (should contain the other bot's ID)
 */
module.exports.run = async (client, message, args) => {
    try {
        const logChannel = client.channels.cache.get('1286082295203369003'); // Error/debugging log channel
        
        // Permission check
        if (!allowedUsers.includes(message.author.id)) {
            return message.channel.send("You don't have permission to use this command.");
        }
        
        // Ensure the other bot's ID is provided
        if (args.length < 1) {
            return message.channel.send("Please provide the other bot's ID.");
        }

        const otherBotId = args[0];

        // Check if the bot is already listening to avoid duplicate listeners
        if (isListening) {
            return message.channel.send("The bot is already listening for the game messages.");
        }

        // Mark that the bot is now listening
        isListening = true;
        message.channel.send(`Listening for messages from bot with ID: ${otherBotId}`);

        // Event listener for message creation
        client.on('messageCreate', async (botMessage) => {
            // Check if the message is from the other bot
            if (botMessage.author.id !== otherBotId) return;

            // Check if the message contains components (buttons)
            if (!botMessage.components || botMessage.components.length === 0) return;

            // Loop through the components and search for a button with "انضمام"
            for (const row of botMessage.components) {
                for (const button of row.components) {
                    if (button.label.includes("انضمام")) {
                        try {
                            // Click the button using proper interaction handling
                            await button.click(); // Attempt the button click
                            logChannel?.send(`Clicked "انضمام" button on message from bot ID: ${otherBotId}`);
                        } catch (error) {
                            logChannel?.send(`Error clicking the button: ${error.message}`);
                        }
                        return;
                    }
                }
            }
        });

    } catch (error) {
        console.error("Error occurred:", error);

        const logChannel = client.channels.cache.get('1286082295203369003');
        logChannel?.send(`Error occurred: \`\`\`${error.message}\`\`\``);
        message.channel.send("An error occurred while trying to join the game.");
    }
};

module.exports.names = {
    list: ["joingame"]
};
