module.exports = {
    showTime: false, // Set to true if you want to show time
    timeZone: "Asia/Kolkata", // Specify your time zone
    Name: "lol Music", // Custom Name/Activity
    State: "Just shut up", // Custom State message
    Details: " lol", // Custom details message
    LargeImage: "https://i.pinimg.com/736x/45/79/cf/4579cf3ed8146995e5fc775e8efb4a2e.jpg", // URL for large image
    SmallImage: "https://i.pinimg.com/736x/45/79/cf/4579cf3ed8146995e5fc775e8efb4a2e.jpg", // URL for small image
    SmallText: "...", // Hover text for small image
};
