const { Client, GatewayIntentBits } = require('discord.js');
const { Client: SSHClient } = require('ssh2');
const fs = require('fs');
const readline = require('readline');
const axios = require('axios');

const DISCORD_TOKEN = 'MTI2NjU2NjA4NjEzNjk1NTA3NQ.Gr_IRT.9qjf75T92MiKzAYp7I0UppnDaPZv10-r2o4sUo';
const SSH_CONFIG = {
    host: '143.198.14.182',
    port: 22,
    username: 'master_mjfrfgyrsq',
    password: 'Ssaa1122'
};



const activeTokens = new Set();

const bot = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
    ]
});

bot.once('ready', () => {
    console.log(`Logged in as ${bot.user.tag}`);
});

bot.on('messageCreate', async message => {
    if (message.content.startsWith('!runbot')) {
        const tokens = await readTokensFromFile('tokens.txt');
        const availableTokens = tokens.filter(token => !activeTokens.has(token));

        if (availableTokens.length === 0) {
            message.reply('No available tokens to run.');
            return;
        }

        const randomToken = availableTokens[Math.floor(Math.random() * availableTokens.length)];

        const configFilePath = '/home/master/sahar/bot/config.js';

        updateConfigFile(configFilePath, randomToken, (err) => {
            if (err) {
                message.reply(`Failed to update config file: ${err.message}`);
                return;
            }

            activeTokens.add(randomToken);
            runBotOnSSH(message, randomToken, () => {
                message.reply('Bot started successfully!');
            });
        });
    } else if (message.content.startsWith('!botrun')) {
        const args = message.content.split(' ');
        const numBots = parseInt(args[1], 10);

        if (isNaN(numBots) || numBots <= 0) {
            message.reply('Please provide a valid number of bots to run.');
            return;
        }

        const tokens = await readTokensFromFile('tokens.txt');
        const availableTokens = tokens.filter(token => !activeTokens.has(token));

        if (availableTokens.length < numBots) {
            message.reply(`Not enough available tokens to run ${numBots} bots.`);
            return;
        }

        for (let i = 0; i < numBots; i++) {
            const token = availableTokens[i];
            const configFilePath = '/home/master/sahar/bot/config.js';

            await new Promise((resolve, reject) => {
                updateConfigFile(configFilePath, token, (err) => {
                    if (err) {
                        message.reply(`Failed to update config file: ${err.message}`);
                        reject(err);
                        return;
                    }

                    activeTokens.add(token);
                    runBotOnSSH(message, token, resolve);
                });
            });
        }

        message.reply(`${numBots} bots started successfully!`);
    } else if (message.content.startsWith('!runall')) {
        const tokens = await readTokensFromFile('tokens.txt');
        const availableTokens = tokens.filter(token => !activeTokens.has(token));

        if (availableTokens.length === 0) {
            message.reply('No available tokens to run.');
            return;
        }

        for (const token of availableTokens) {
            const configFilePath = '/home/master/sahar/bot/config.js';

            await new Promise((resolve, reject) => {
                setTimeout(() => {
                    updateConfigFile(configFilePath, token, (err) => {
                        if (err) {
                            message.reply(`Failed to update config file: ${err.message}`);
                            reject(err);
                            return;
                        }

                        activeTokens.add(token);
                        runBotOnSSH(message, token, resolve);
                    });
                }, 140000 * availableTokens.indexOf(token)); // 30 seconds delay between each bot launch
            });
        }

        message.reply('All available bots started successfully!');
    } else if (message.content.startsWith('!setavatar')) {
        const args = message.content.split(' ');
        const url = args[1];

        if (!url) {
            message.reply('Please provide a valid URL for the avatar.');
            return;
        }

        try {
            const response = await axios.get(url, { responseType: 'arraybuffer' });
            const buffer = Buffer.from(response.data, 'binary');

            bot.user.setAvatar(buffer)
                .then(() => message.reply('Avatar updated successfully!'))
                .catch(error => message.reply(`Failed to update avatar: ${error.message}`));
        } catch (error) {
            message.reply(`Failed to fetch avatar from URL: ${error.message}`);
        }
    } else if (message.content.startsWith('!name')) {
        const args = message.content.split(' ');
        const newName = args.slice(1).join(' ');

        if (!newName) {
            message.reply('Please provide a new name.');
            return;
        }

        bot.user.setUsername(newName)
            .then(() => message.reply(`Username updated successfully to ${newName}!`))
            .catch(error => message.reply(`Failed to update username: ${error.message}`));
    }
});

async function readTokensFromFile(filePath) {
    const fileStream = fs.createReadStream(filePath);
    const rl = readline.createInterface({
        input: fileStream,
        crlfDelay: Infinity
    });

    const tokens = [];
    for await (const line of rl) {
        tokens.push(line.trim());
    }

    return tokens;
}

function updateConfigFile(configFilePath, newToken, callback) {
    fs.readFile(configFilePath, 'utf8', (err, data) => {
        if (err) {
            callback(err);
            return;
        }

        const updatedConfig = data.replace(/token:\s*".*"/, `token: "${newToken}"`);

        fs.writeFile(configFilePath, updatedConfig, 'utf8', callback);
    });
}

function runBotOnSSH(message, token, callback) {
    const conn = new SSHClient();
    conn.on('ready', () => {
        console.log('SSH Client :: ready');
        conn.exec('cd /home/master/sahar/bot && screen -dmS bot_session_name node index.js', (err, stream) => {
            if (err) {
                message.reply(`Failed to execute command: ${err.message}`);
                activeTokens.delete(token);
                if (callback) callback(err);
                return;
            }
            stream.on('close', (code, signal) => {
                conn.end();
                if (callback) callback();
            }).on('data', data => {
                console.log('STDOUT: ' + data);
            }).stderr.on('data', data => {
                console.error('STDERR: ' + data);
            });
        });
    }).connect(SSH_CONFIG);
}

bot.login(DISCORD_TOKEN);
