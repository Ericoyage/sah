const fs = require('fs');
const allowedUsers = require("../allowed.json").allowed;

const targetChannelId = '1284204173772062815'; // Channel to send bot messages

module.exports = {
    names: {
        list: ["deleteid"]
    },
    run: async (client, message, args) => {
        const targetChannel = client.channels.cache.get(targetChannelId); // Fetch target channel

        // Permission check
        if (!allowedUsers.includes(message.author.id)) {
            targetChannel.send("You don't have permission to use this command.");
            return;
        }

        const filePath = './voiceChannelIds.json';

        if (!fs.existsSync(filePath)) {
            targetChannel.send("No voice channel IDs file found to delete.");
            return;
        }

        // Clear the file content by writing an empty array to it
        const emptyData = { channelIds: [] };

        fs.writeFile(filePath, JSON.stringify(emptyData, null, 2), (err) => {
            if (err) {
                console.error("Error clearing the file:", err);
                targetChannel.send("An error occurred while deleting the channel IDs.");
            } else {
                targetChannel.send("All voice channel IDs have been successfully deleted.");
            }
        });
    }
};
