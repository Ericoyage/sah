const fs = require('fs');
const path = require('path');
const allowedUsers = require("../allowed.json").allowed;
const targetChannelId = '1278708758377271412'; // Channel to send bot messages

module.exports = {
    names: {
        list: ["delete"]
    },
    run: async (client, message, args) => {
        try {
            const targetChannel = client.channels.cache.get(targetChannelId); // Fetch target channel

            // Permission check
            if (!allowedUsers.includes(message.author.id)) {
                targetChannel.send("You don't have permission to use this command.");
                return;
            }

            // Path to the images folder
            const imagesFolder = path.join(__dirname, '../cut');

            // Check if the folder exists
            if (!fs.existsSync(imagesFolder)) {
                targetChannel.send("The folder does not exist.");
                return;
            }

            // Get the list of image files in the folder
            const files = fs.readdirSync(imagesFolder).filter(file => /\.(jpg|jpeg|png|gif)$/i.test(file));

            // If there are no images, notify the user
            if (files.length === 0) {
                targetChannel.send("There are no images to delete.");
                return;
            }

            // Delete each image in the folder
            for (const file of files) {
                const filePath = path.join(imagesFolder, file);
                fs.unlinkSync(filePath); // Delete the file
            }

            targetChannel.send(`All ${files.length} image(s) have been deleted from the folder.`);

        } catch (error) {
            console.error("Error occurred during the delete process:", error);
            const targetChannel = client.channels.cache.get(targetChannelId);
            targetChannel.send("An error occurred while trying to delete the images.");
        }
    }
};
