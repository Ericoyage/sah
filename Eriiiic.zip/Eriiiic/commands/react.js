const { joinVoiceChannel, getVoiceConnection } = require('@discordjs/voice');
const allowedUsers = require("../allowed.json").allowed;

const targetChannelId = '1284204173772062815'; // Channel to send bot messages

module.exports = {
    names: {
        list: ["react"]
    },
    run: async (client, message, args) => {
        try {
            const targetChannel = client.channels.cache.get(targetChannelId); // Fetch target channel

            // Permission check
            if (!allowedUsers.includes(message.author.id)) {
                targetChannel.send("You don't have permission to use this command.");
                return;
            }

            // Check if both arguments are provided
            if (args.length < 2) {
                targetChannel.send("Please provide both the message link and emoji.");
                return;
            }

            const messageLink = args[0];
            const emoji = args[1];

            // Extract the message ID from the link
            const messageId = messageLink.split('/').pop();
            if (!messageId) {
                targetChannel.send("Invalid message link.");
                return;
            }

            // Fetch the message from the link
            try {
                const fetchedMessage = await message.channel.messages.fetch(messageId);

                // React to the message with the provided emoji
                await fetchedMessage.react(emoji);

                // Optional: Confirm action to the command sender
                await message.react("✅");
            } catch (fetchError) {
                message.react("❌");
            }

        } catch (error) {
            console.error("Error occurred during the event:", error);
            const targetChannel = client.channels.cache.get(targetChannelId);
            targetChannel.send("An error occurred while handling the reaction command.");
        }
    }
};
