const fs = require('fs');
const allowedUsers = require("../allowed.json").allowed;

const targetChannelId = '1284204173772062815'; // Channel to send bot messages

module.exports = {
    names: {
        list: ["addid"]
    },
    run: async (client, message, args) => {
        const targetChannel = client.channels.cache.get(targetChannelId); // Fetch target channel

        // Permission check
        if (!allowedUsers.includes(message.author.id)) {
            targetChannel.send("You don't have permission to use this command.");
            return;
        }

        if (args.length < 1) {
            targetChannel.send("Please provide a list of voice channel IDs (comma-separated).");
            return;
        }

        // Split the input into individual IDs
        const ids = args[0].split(',').map(id => id.trim());

        // Save the IDs to a JSON file
        const filePath = './voiceChannelIds.json';
        const data = { channelIds: ids };

        fs.writeFile(filePath, JSON.stringify(data, null, 2), (err) => {
            if (err) {
                console.error("Error writing to file:", err);
                targetChannel.send("An error occurred while saving the channel IDs.");
            } else {
                targetChannel.send(`Voice channel IDs saved: ${ids.join(', ')}`);
            }
        });
    }
};
