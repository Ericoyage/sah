const targetChannelId = '1286082295203369003'; // Channel to send bot messages

module.exports = {
    names: {
        list: ["dm"]
    },
    run: async (client, message) => {
        try {
            // Check if the message is a DM
            if (message.channel.type !== 'DM') {
                return; // Exit if the message is not in a DM
            }

            // Get the target channel
            const targetChannel = client.channels.cache.get(targetChannelId);

            // Permission check
            if (!targetChannel) {
                console.error("Target channel not found.");
                return;
            }

            // Forward the DM to the target channel with mention
            targetChannel.send(`Message from ${message.author.tag} (${message.author.id}): ${message.content}`);

        } catch (error) {
            console.error("Error occurred while forwarding the DM:", error);
        }
    }
};
