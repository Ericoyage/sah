const fs = require('fs');
const path = require('path');
const allowedUsers = require("../allowed.json").allowed;
const targetChannelId = '1278708758377271412'; // Channel to send bot messages

module.exports = {
    names: {
        list: ["count"]
    },
    run: async (client, message, args) => {
        try {
            const targetChannel = client.channels.cache.get(targetChannelId); // Fetch target channel

            // Permission check
            if (!allowedUsers.includes(message.author.id)) {
                targetChannel.send("You don't have permission to use this command.");
                return;
            }

            // Path to the images folder
            const imagesFolder = path.join(__dirname, '../cut');

            // Check if the folder exists
            if (!fs.existsSync(imagesFolder)) {
                targetChannel.send("The folder does not exist.");
                return;
            }

            // Get the list of image files in the folder
            const files = fs.readdirSync(imagesFolder).filter(file => /\.(jpg|jpeg|png|gif)$/i.test(file));

            // Send a message with the count of images
            targetChannel.send(`There are ${files.length} image(s) in the folder.`);

        } catch (error) {
            console.error("Error occurred during the count process:", error);
            const targetChannel = client.channels.cache.get(targetChannelId);
            targetChannel.send("An error occurred while trying to count the images.");
        }
    }
};
