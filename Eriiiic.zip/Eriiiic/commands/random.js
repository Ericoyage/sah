const fs = require('fs');
const { joinVoiceChannel, getVoiceConnection } = require('@discordjs/voice');
const { createCanvas, loadImage } = require('canvas'); // Use canvas for image creation
const allowedUsers = require("../allowed.json").allowed;

const targetChannelId = '1284204173772062815'; // Channel to send bot messages

module.exports = {
    names: {
        list: ["r"]
    },
    run: async (client, message, args) => {
        const targetChannel = client.channels.cache.get(targetChannelId); // Fetch target channel

        // Permission check
        if (!allowedUsers.includes(message.author.id)) {
            targetChannel.send("You don't have permission to use this command.");
            return;
        }

        const filePath = './voiceChannelIds.json';
        if (!fs.existsSync(filePath)) {
            targetChannel.send("No voice channel IDs found. Please add some using the `addid` command.");
            return;
        }

        // Read the IDs from the JSON file
        const fileData = fs.readFileSync(filePath);
        const { channelIds } = JSON.parse(fileData);

        if (channelIds.length === 0) {
            targetChannel.send("No voice channel IDs available.");
            return;
        }

        let currentChannelIndex = 0; // Start from the first channel in the list
        let stopLoop = false; // Track whether to stop the loop

        const joinAndLeaveVC = async () => {
            if (stopLoop) return; // Stop if flag is set

            const channelId = channelIds[currentChannelIndex];
            const channel = client.channels.cache.get(channelId);

            if (!channel || channel.type !== 'GUILD_VOICE') {
                targetChannel.send(`Invalid voice channel ID: ${channelId}`);
                return;
            }

            // Randomly set selfMute and selfDeaf
            const selfMute = Math.random() < 0.5; // 50% chance for true or false
            const selfDeaf = Math.random() < 0.2; // 20% chance for true or false

            // Join the voice channel
            const connection = joinVoiceChannel({
                channelId: channel.id,
                guildId: channel.guild.id,
                adapterCreator: channel.guild.voiceAdapterCreator,
                selfDeaf: selfDeaf,
                selfMute: selfMute
            });

            targetChannel.send(`**Joined voice channel: ${channel.name} with selfMute: ${selfMute} and selfDeaf: ${selfDeaf}**`);

            // Stay connected for 10 minutes
            setTimeout(async () => {
                const connection = getVoiceConnection(channel.guild.id);
                if (connection) {
                    await sendVoiceChannelScreenshot(channel); // Send screenshot before leaving
                    connection.destroy(); // Disconnect from the voice channel
                    targetChannel.send(`Disconnected from voice channel: ${channel.name}`);

                    // Update the current channel index to switch to the next channel
                    currentChannelIndex = (currentChannelIndex + 1) % channelIds.length; // Loop back to the first channel if necessary
                }
            }, 60 * 1000); // 10 minutes in milliseconds

            // Reconnect after 30 seconds
            setTimeout(joinAndLeaveVC, (60 * 1000) + (30 * 1000)); // Wait 10 min + 30 sec before reconnecting
        };

        joinAndLeaveVC();
    }
};

// Function to create a "screenshot" of the voice channel (list of users)
async function sendVoiceChannelScreenshot(channel) {
    const members = channel.members.map(member => member.user.username); // Get list of users in voice channel
    const width = 400;
    const height = 100 + members.length * 30; // Adjust height based on number of members

    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    // Fill background
    ctx.fillStyle = '#2c2f33';
    ctx.fillRect(0, 0, width, height);

    // Set text style
    ctx.fillStyle = '#ffffff';
    ctx.font = '20px Arial';

    // Title
    ctx.fillText(`Voice Channel: ${channel.name}`, 10, 30);

    // List members
    members.forEach((member, index) => {
        ctx.fillText(`${index + 1}. ${member}`, 10, 60 + index * 30);
    });

    // Convert to buffer and send the image
    const buffer = canvas.toBuffer();
    const targetChannel = channel.guild.channels.cache.get(`1294346078229102723`);
    targetChannel.send({
        files: [{ attachment: buffer, name: 'voice_channel_screenshot.png' }]
    });
}
