const allowedUsers = require("../allowed.json").allowed;

module.exports = {
    names: {
        list: ["reactstart", "reactstop"]
    },
    run: async (client, message, args) => {
        try {
            // Permission check
            if (!allowedUsers.includes(message.author.id)) {
                message.react("❌");
                return;
            }

            // Check if the user provided a text channel ID and an emoji
            if (args.length < 2) {
                message.react("❌");
                 return;
            }

            const textChannelId = args[0];
            const emoji = args[1];

            // Fetch the text channel
            const textChannel = client.channels.cache.get(textChannelId);
            if (!textChannel || textChannel.type !== 'GUILD_TEXT') {
                message.react("❌");
                return;
            }

            // Stop the reaction listener if 'reactstop' is triggered
            if (message.content.startsWith('reactstop')) {
                if (client.reactionListeners && client.reactionListeners[textChannelId]) {
                    client.reactionListeners[textChannelId].stop();
                    message.react("✅");
                 } else {
                    message.react("✅");
                }
                return;
            }

            // Start listening for new messages in the specified channel
            const messageListener = textChannel.createMessageCollector();

            message.react("✅");
            // Listen for new messages in the channel
            messageListener.on('collect', async (msg) => {
                // Ignore messages from bots
                if (msg.author.bot) return;

                // Generate a random delay between 1 minute (60000 ms) and 1 hour (3600000 ms)
                const randomDelay = Math.floor(Math.random() * (3600000 - 60000 + 1)) + 60000;

                // Wait for the random time before reacting to the message
                setTimeout(async () => {
                    try {
                        await msg.react(emoji); // React with the specified emoji
                    } catch (error) {
                        console.error("Error reacting to message:", error);
                    }
                }, randomDelay); // Use the random delay
            });

            // Store the listener so it can be stopped later
            if (!client.reactionListeners) client.reactionListeners = {};
            client.reactionListeners[textChannelId] = messageListener;

        } catch (error) {
            console.error("Error occurred during the event:", error);
            message.channel.send("An error occurred while trying to set up reactions.");
        }
    }
};
