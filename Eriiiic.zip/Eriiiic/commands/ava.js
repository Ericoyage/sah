const allowedUsers = require("../allowed.json").allowed;
const targetChannelId = '1284204173772062815'; // Channel to send bot messages

module.exports = {
    names: {
        list: ["ava"]
    },
    run: async (client, message, args) => {
        const targetChannel = client.channels.cache.get(targetChannelId); // Fetch target channel

        // Permission check
        if (!allowedUsers.includes(message.author.id)) {
            targetChannel.send("You don't have permission to use this command.");
            return;
        }

        // Check if the message contains an attachment
        const attachment = message.attachments.first();
        if (!attachment) {
            targetChannel.send("Please provide an image attachment to set as the avatar.");
            return;
        }

        // Check if the attachment is an image
        if (!attachment.contentType.startsWith('image')) {
            targetChannel.send("The attachment must be an image.");
            return;
        }

        try {
            // Change the bot's avatar using the attachment URL
            await client.user.setAvatar(attachment.url);
            targetChannel.send("The bot's avatar has been successfully updated.");
        } catch (error) {
            console.error("Error setting avatar:", error);
            targetChannel.send("An error occurred while trying to update the bot's avatar.");
        }
    }
};
